﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MileStone_Attendance_Management.Data.Migrations
{
    public partial class SectionsAssignedTableAdded2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
       
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
           
        }
    }
}
